# Menu with speed gauge effect

A Pen created on CodePen.io. Original URL: [https://codepen.io/onediv/pen/LYzwENb](https://codepen.io/onediv/pen/LYzwENb).

A vertical menu with gooey effect on hover.